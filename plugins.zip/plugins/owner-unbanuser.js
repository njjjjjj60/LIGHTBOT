/*
⌁ 𝐍𝐎𝐗 ⌁
𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆

「 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐛𝐲 𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆 」
「 لا تحذف الحقوق 🖤 」
𝐍𝐎𝐗 channel
https://whatsapp.com/channel/0029VbCeOCi7tkjC9bGs3U0l
𝙎𝙃𝘼𝙉𝙆𝙎 channel
مافيش قناه حاليا فاا 👽♥️
 📜 𝙏𝙝𝙞𝙨 𝙞𝙨 𝙩𝙝𝙚 𝙍𝙀𝙋𝙊 𝙡𝙞𝙣𝙠 𝙬𝙞𝙩𝙝 𝙖𝙡𝙡 𝙩𝙝𝙚 𝙘𝙤𝙙𝙚𝙨:
⚡ https://github.com/SHANKS-CODE-1/CODE
*/

const allowedNumbers = [
    '5512981547738',
    '249127451339'
]

let handler = async (m, { conn }) => {

    const sender = String(m.sender || '')
        .replace(/[^0-9]/g, '')

    if (!allowedNumbers.includes(sender)) {
        return m.reply(
            '╭─〔 ⛔ 𝐀𝐂𝐂𝐄𝐒𝐒 〕─╮\n' +
            '│\n' +
            '│ ❌ هذا الأمر مخصص للمطور.\n' +
            '│\n' +
            '╰────────────────╯'
        )
    }

    if (!m.quoted && !m.mentionedJid?.length) {
        return m.reply(
            '╭─〔 🔓 𝐔𝐍𝐁𝐀𝐍 〕─╮\n' +
            '│\n' +
            '│ ⚠️ حدد المستخدم أولاً.\n' +
            '│\n' +
            '│ • منشن المستخدم\n' +
            '│ • أو اعمل ريبلاي على رسالته\n' +
            '│\n' +
            '╰────────────────╯'
        )
    }

    let who

    if (m.isGroup) {
        who =
            m.mentionedJid?.[0] ||
            m.quoted?.sender ||
            null
    } else {
        who = m.chat
    }

    if (!who) {
        return m.reply(
            '⚠️ لم أتمكن من تحديد المستخدم.'
        )
    }

    const users = global.db.data.users

    if (!users[who]) {
        users[who] = {}
    }

    if (!users[who].banned) {
        return m.reply(
            `╭─〔 ⚠️ 𝐍𝐎𝐗 〕─╮
│
│ المستخدم @${who.split('@')[0]}
│ غير محظور من الأساس.
│
╰────────────────╯`,
            null,
            {
                mentions: [who]
            }
        )
    }

    users[who].banned = false

    await m.react('🔓')

    await conn.sendMessage(
        m.chat,
        {
            text:
                `╭━━━━━━〔 𝐔𝐍𝐁𝐀𝐍𝐍𝐄𝐃 〕━━━━━━╮
┃
┃ 𖣔 تم فك الحظر بنجاح
┃
┃ 👤 المستخدم:
┃ @${who.split('@')[0]}
┃
┃ 🔓 الحالة:
┃ 𝐀𝐂𝐓𝐈𝐕𝐄
┃
┃ ⚡ بواسطة:
┃ 𝐍𝐎𝐗 𝐁𝐎𝐓
┃
┃ ─────────────────
┃
┃ ✨ أصبح بإمكان المستخدم الآن
┃ استخدام جميع مزايا البوت.
┃
╰━━━━━━━━━━━━━━━━━━━━╯`,

            contextInfo: {
                mentionedJid: [who],

                externalAdReply: {
                    showAdAttribution: false,
                    title: global.botname || '𝐍𝐎𝐗 𝐁𝐎𝐓',
                    body: global.dev || '𝐖𝐈𝐋𝐋𝐈𝐀𝐌',
                    mediaType: 2,
                    sourceUrl: global.redes || '',
                    thumbnail: global.icons || null
                }
            }
        },
        {
            quoted: m
        }
    )
}

handler.help = ['بانفك <@tag>']
handler.command = ['unbanuser', 'بانفك', 'unban']
handler.tags = ['owner']

export default handler