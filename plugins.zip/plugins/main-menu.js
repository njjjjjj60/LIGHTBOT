/*
⌁ 𝐍𝐎𝐗 ⌁
𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ⌁ 𝑮𝑬𝑶

「 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐛𝐲 𝑮𝑬𝑶 」
「 لا تحذف الحقوق 🖤 」
𝐍𝐎𝐗 channel
https://whatsapp.com/channel/0029VbCeOCi7tkjC9bGs3U0l
𝙎𝙃𝘼𝙉𝙺𝙎 channel
مافيش قناه حاليا فاا 👽♥️
 📜 𝙏𝙝𝙞𝙨 𝙞𝙨 𝙩𝙝𝙚 𝙍𝙀𝙋𝙊 𝙡𝙞𝙣𝙠 𝙬𝙞𝙩𝙝 𝙖𝙡𝙡 𝙩𝙝𝙚 𝙘𝙤𝙙𝙚𝙨:
⚡ https://github.com/SHANKS-CODE-1/CODE
*/

import moment from "moment-timezone"
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys'
import fs from 'fs'
import path from 'path'
import axios from 'axios'

// رابط الصورة ومسار حفظها
const IMAGE_URL = 'https://files.catbox.moe/9n2xcd.mp4' // استبدل هذا الرابط برابط صورتك لو أردت
const MENU_DIR = path.join(process.cwd(), 'src', 'menu')
const MENU_FILE = path.join(MENU_DIR, 'menu.jpg')

const categoryNames = {
  'main':         '✨ الـرئـيـسـيـة',
  'owner':        '👑 الـمـطـور',
  'ai':           '🤖 الـذكـاء الاصـطـنـاعـي',
  'anime':        '🌸 الأنـمـي والـمـانـجـا',
  'economy':      '💰 الاقـتـصـاد',
  'game':         '🎮 الألـعـاب',
  'group':        '🛡️ إدارـة الـمـجـمـوعـات',
  'grupo':        '👥 أدوّات الـجـروّبـات',
  'info':         '📖 الـمـعـلـوّمـات',
  'internet':     '🌐 الإنـتـرنـت',
  'sticker':      '🏷️ الـمـلـصـقـات',
  'tools':        '🧰 الأدوات',
  'download':     '⬇️ الـتـنـزيـل',
  'downloader':   '📥 الـتـحـمـيـل',
  'daily':        '📅 الـيـوّمـيـات',
  'serbot':       '🤖 رـبـط الـبـوّتـات',
  'image':        '🖼️ الـصـوّر',
  'herramientas': '🔧 الـخـدمـات',
  'nable':        '🔌 الـتـفـعـيـلات',
}

const tagIcons = {
  'main':         '✨',
  'owner':        '👑',
  'ai':           '🤖',
  'anime':        '🌸',
  'economy':      '💰',
  'game':         '🎮',
  'group':        '🛡️',
  'grupo':        '👥',
  'info':         'ℹ️',
  'internet':     '🌐',
  'sticker':      '🏷️',
  'tools':        '🧰',
  'download':     '⬇️',
  'downloader':   '📥',
  'daily':        '📅',
  'serbot':       '🤖',
  'image':        '🖼️',
  'herramientas': '🔧',
  'nable':        '🔌',
}

async function ensureMenuImage() {
  if (!fs.existsSync(MENU_DIR)) {
    fs.mkdirSync(MENU_DIR, { recursive: true })
  }
  if (!fs.existsSync(MENU_FILE)) {
    const res = await axios.get(IMAGE_URL, { responseType: 'arraybuffer' })
    fs.writeFileSync(MENU_FILE, Buffer.from(res.data))
  }
  return fs.readFileSync(MENU_FILE)
}

function getActiveTags() {
  return [...new Set(
    Object.values(global.plugins || {})
      .filter(p => !p.disabled && p.tags)
      .flatMap(p => Array.isArray(p.tags) ? p.tags : [p.tags])
  )].filter(Boolean)
}

function getCategoryRows(tags) {
  return tags.map(tag => ({
    title: `${tagIcons[tag] || '📂'} ${categoryNames[tag] || tag}`,
    description: `عـرض أواـمـر ${categoryNames[tag] || tag}`,
    id: `.اوامر ${tag}`
  }))
}

function getCommandsByTag(tag) {
  return Object.values(global.plugins || {})
    .filter(p => !p.disabled && p.tags && (Array.isArray(p.tags) ? p.tags : [p.tags]).includes(tag))
    .flatMap(p => (Array.isArray(p.help) ? p.help : [p.help]).filter(Boolean))
    .map(cmd => `│ ⚡ .${cmd}`)
}

async function sendCategoryMenu(m, conn, tag) {
  const cmds = getCommandsByTag(tag)
  const catName = categoryNames[tag] || tag
  const icon = tagIcons[tag] || '📂'

  const txt = `╭───〔 🦂  ${icon} ${catName.toUpperCase()}  〕───╮
│
│  ─────────────
│  ⚡ 𝑪𝑶𝑑𝑴𝑨𝑵𝑫 𝑪𝑬𝑵𝑻𝑬𝑹
│  ─────────────
│
${cmds.length === 0 ? '│  ⚠️ لا تـوّجـد أوّامـر فـي هـذا الـقـسـم حـالـيـاً' : cmds.join('\n')}
│
│ 𝑷𝒐𝒘𝒆𝒓, 𝑺𝒊𝒎𝒑𝒍𝒊𝒄𝒊𝒕𝒚, 𝑵𝒐𝒙.
┕─────────────────────┙

│  ─── 𝑵𝒐𝒙 🏎️
│  ─── 𝑫𝒆𝒗: 𝑮𝑬𝑶 👑

©𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝑩𝒚 ─── 𝑵𝒐𝒙 🏎️`

  try {
    const imageBuffer = await ensureMenuImage()
    const mediaMessage = await prepareWAMessageMedia(
      { image: imageBuffer },
      { upload: conn.waUploadToServer }
    )

    const allTags = getActiveTags()
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: { hasMediaAttachment: true, imageMessage: mediaMessage.imageMessage },
            body: { text: txt },
            footer: { text: "⚡ 𝙉𝙊𝙓 𝘽𝙊𝙏 | 𝑫𝒆𝒗: 𝑮𝑬𝑶" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "📂 اـخـتـار قـسـم آخـر",
                    sections: [{ title: '📂 أـقـسـام الـبـوّت', rows: getCategoryRows(allTags) }]
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🔙 رـجـوّع لـلـرئـيـسـيـة",
                    id: ".اوامر"
                  })
                }
              ]
            }
          }
        }
      }
    }, { quoted: m })

    return await conn.relayMessage(m.chat, msg.message, {})
  } catch (e) {
    return await conn.sendMessage(m.chat, { text: txt }, { quoted: m })
  }
}

let handler = async (m, { conn, usedPrefix, args }) => {
  try {
    const tag = args[0]?.trim().toLowerCase()
    if (tag && categoryNames[tag]) {
      return await sendCategoryMenu(m, conn, tag)
    }

    const txt = `╭───〔 🦂  𝐍𝐎𝐗 𝐕𝟐  〕───╮
│
│  ─────────────
│  ⚡ 𝑪𝑶𝑑𝑴𝑨𝑵𝑫 𝑪𝑬𝑵𝑻𝑬𝑹
│  ─────────────
│
│  إخـتـر قـسـم الأواـمـر مـن الـقـائـمـة أسـفـلـه ⚡
│
│ 𝑷𝒐𝒘𝒆𝒓, 𝑺𝒊𝒎𝒑𝒍𝒊𝒄𝒊𝒕𝒚, 𝑵𝒐𝒙.
┕─────────────────────┙

│  ─── 𝑵𝒐𝒙 🏎️
│  ─── 𝑫𝒆𝒗: 𝑮𝑬𝑶 👑

©𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝑩𝒚 ─── 𝑵𝒐𝒙 🏎️`

    await conn.sendMessage(m.chat, { react: { text: '‍🌓', key: m.key } })

    const imageBuffer = await ensureMenuImage()
    const mediaMessage = await prepareWAMessageMedia(
      { image: imageBuffer },
      { upload: conn.waUploadToServer }
    )

    const allTags = getActiveTags()

    const shanksSections = [
      {
        title: "Ｎｏｘ Ｂｏｔ",
        highlight_label: "⚡ خـيـارـات سـرـيـعـة",
        rows: [
          { title: "لـجـروبـات الـبـوت", description: "عـرـض جـمـيـع الـجـرـوّبـات الـخـاصـة بـالـبـوّت", id: `${usedPrefix}جروبات-البوت` },
          { title: "حـالـة الـنـظـام", description: "فـحـص الـسـرـعـة والأداء", id: `${usedPrefix}ping` },
          { title: "لـلـمـطـوّر", description: "مـطـوّر الـبـوّت 𝑮𝑬𝑶 👑", id: `${usedPrefix}مطور` }
        ]
      }
    ]

    const sectionsOnly = [
      {
        title: "📂 أـقـسـام الـبـوّت",
        rows: getCategoryRows(allTags)
      }
    ]

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: true,
              imageMessage: mediaMessage.imageMessage
            },
            body: { text: txt },
            footer: { text: "𝙉𝙤𝙭 𝘽𝙤𝙩 | 𝑫𝒆𝒗: 𝑮𝑬𝑶" },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "واـجـهـة ＃ 𝙽𝙾𝚇 🌓",
                    sections: shanksSections
                  })
                },
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "📂 الأقـسـام",
                    sections: sectionsOnly
                  })
                }
              ]
            },
            contextInfo: {
              mentionedJid: [m.sender],
              isForwarded: true,
              forwardingSlib: 999999
            }
          }
        }
      }
    }, { quoted: m })

    return await conn.relayMessage(m.chat, msg.message, {})

  } catch (e) {
    console.error(e)
    return conn.reply(m.chat, "❌ حـصـل خـطـأ أثـنـاء تـشـغـيـل الـقـائـمـة", m)
  }
}

handler.command = [
  'menu','help','allmenu',
  'الاوامر','اوامر','اومرو','امور','أوامر',
  'القائمه','القائمة'
]

handler.help = ['اوامر']
handler.tags = ['main']

export default handler