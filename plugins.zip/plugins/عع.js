/*
 * 📂 patch_sonic.js - البحث عن الملفات برقم أو اسم الأمر (.عع)
 * 👤 الأوامر : .عع
 * 👨🏻‍💻 الـمُـطَـوِّر: 𝑺𝑶𝑵𝑰𝑪 𝑫𝑬𝑽⃢҉ ســونـيــڪ
 * 🎯 الـبُـوت: ⃟꙰⃢  𝚂𝙾𝙽𝙸𝙲➥𝙱ᝪᝨ ❯ |‌⃟🇲🇦‌|‌
 */

import fs from 'fs'
import path from 'path'

// دالة جلب كل الملفات من المجلدات
const scanPlugins = (dir, base = '') => {
   let results = []
   const items = fs.readdirSync(dir)
   for (const item of items) {
      const fullPath = path.join(dir, item)
      const stat = fs.statSync(fullPath)
      if (stat.isDirectory()) {
         const subBase = base ? `${base}/${item}` : item
         results = results.concat(scanPlugins(fullPath, subBase))
      } else if (item.endsWith('.js') || item.endsWith('.json')) {
         const name = base
            ? `${base}/${item.replace(/\.(js|json)$/, '')}`
            : item.replace(/\.(js|json)$/, '')
         results.push({ name, fullPath })
      }
   }
   return results
}

// دالة الفحص داخل handler.command فقط
const checkHandlerCommand = (filePath, searchTerm) => {
   try {
      const content = fs.readFileSync(filePath, 'utf-8')
      const cleanSearch = searchTerm.toLowerCase().trim()

      const commandLineMatch = content.match(/(?:handler\.)?command\s*=\s*(.+)/i)
      if (!commandLineMatch) return false

      const commandValue = commandLineMatch[1].trim()

      // 1. فحص الـ Regex
      const regexMatch = commandValue.match(/^\/(.+?)\/([a-z]*)/i)
      if (regexMatch) {
         try {
            const pattern = new RegExp(regexMatch[1], regexMatch[2])
            return pattern.test(cleanSearch)
         } catch (e) {
            return false
         }
      }

      // 2. فحص المصفوفات Array
      if (commandValue.startsWith('[')) {
         const items = commandValue
            .replace(/[\[\]]/g, '')
            .split(',')
            .map(s => s.replace(/['"`\s]/g, '').toLowerCase())
         return items.includes(cleanSearch)
      }

      // 3. فحص النصوص العادية
      const stringMatch = commandValue.match(/^['"`](.*?)['"`]/)
      if (stringMatch) {
         return stringMatch[1].toLowerCase() === cleanSearch
      }

      return false
   } catch (e) {
      return false
   }
}

let handler = async (m, { text }) => {
   const pluginsDir = path.join(process.cwd(), 'plugins')
   const allPlugins = scanPlugins(pluginsDir)

   // 1. عند كتابة الأمر فارغاً (.عع) -> عرض قائمة بجميع ملفات السيرفر
   if (!text) {
      if (!allPlugins.length)
         return m.reply('🚫 لا توجد ملفات أو إضافات حالياً في السيرفر!')

      let caption = `⚡ *قَـائِـمَـةُ مَـلَـفَّـاتِ الـسِّـيرْفَـرِ*\n`
      caption += `🤖 للبحث عن ملفات أمر معين، اكتب: \`.عع [الأمر]\`\n\n`
      caption += `📁 *إجمالي الملفات:* ${allPlugins.length}\n`
      caption += `-----------------------------------\n`

      allPlugins.forEach((v, i) => {
         caption += `*${i + 1}.* \`${v.name}\`\n`
      })

      return m.reply(caption.trim())
   }

   // 2. البحث عن كل الملفات التي تمتلك هذا الأمر في handler.command
   const query = text.trim().toLowerCase().replace(/^\./, '')
   const matchingPlugins = allPlugins.filter(v => checkHandlerCommand(v.fullPath, query))

   if (!matchingPlugins.length)
      return m.reply(`❌ لَمْ يَتِمَّ الـعَـثُـورُ عَـلَى أَيِّ مَـلَفّ يَرْتَبِطُ بِالأَمْرِ: *${text}* فِي \`handler.command\`\n\n📂 اكْـتُـبِ الأَمْـرَ \`.عع\` فَقَطْ لِعَرْضِ الـقَـائِـمَـةِ الـكَـامِـلَـةِ.`)

   // 3. إرسال أسماء ومسارات الملفات المعثور عليها فقط
   let response = `🎯 *نَـتَـائِـجُ الـبَـحْـثِ عَـنِ الأَمْـرِ:* \`${query}\`\n`
   response += `📊 *عـدد المـلـفـات المـعـثـور عـلـيـهـا:* ${matchingPlugins.length}\n\n`

   matchingPlugins.forEach((file, index) => {
      const relativePath = path.relative(pluginsDir, file.fullPath).replace(/\\/g, '/')
      response += `*${index + 1}.* 📄 *الاسم:* \`${file.name}\`\n`
      response += `   💻 *المسار:* \`/plugins/${relativePath}\`\n\n`
   })

   return m.reply(response.trim())
}

handler.help = ['عع']
handler.command = /^عع$/i
handler.tags = ['owner']
handler.owner = true

export default handler