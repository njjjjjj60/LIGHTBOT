/*
⌁ 𝐍𝐎𝐗 ⌁
𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆

「 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐛𝐲 𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆 」
「 لا تحذف الحقوق 🖤 」
𝐍𝐎𝐗 channel
https://whatsapp.com/channel/0029VbCeOCi7tkjC9bGs3U0l
𝙎𝙃𝘼𝙉𝙆𝙎 channel
مافيش قناه حاليا فاا 👽♥️
 📜 𝙏𝙝𝙞𝙨 𝙞𝙨 𝙩𝙝𝙚 𝙍𝙀𝙋𝙊 𝙡𝙞𝙣𝙠 𝙬𝙞𝙩𝙝 𝙖𝙡𝙡 𝙩𝙝𝙚 𝙘𝙤𝙙𝙚𝙨:
⚡ https://github.com/SHANKS-CODE-1/CODE
*/

let handler = async (m, { conn }) => {
  if (!m.quoted) {
    return conn.reply(
      m.chat,
      `> ＃ 𝙽𝙾𝚇 〢 𝙸𝙼𝙰𝙶𝙴
>
> 🖼️ قم بالرد على ملصق
> لتحويله إلى صورة.
>
> 𝑮𝑬𝑶 × 𝐴𝑅𝐸𝑆`,
      m
    )
  }

  try {
    await m.react('🕒')

    let imgBuffer = await m.quoted.download()

    if (!imgBuffer) {
      await m.react('✖️')

      return conn.reply(
        m.chat,
        `> ＃ 𝙽𝙾𝚇 〢 𝙴𝚁𝚁𝙾𝚁
>
> ⚠️ تعذّر قراءة الملصق.
> جرّب ملصقاً آخر.
>
> 𝑮𝑬𝑶 × 𝐴𝑅𝐸𝑆`,
        m
      )
    }

    await conn.sendMessage(
      m.chat,
      {
        image: imgBuffer,
        caption: `> ＃ 𝙽𝙾𝚇 〢 𝙸𝙼𝙰𝙶𝙴
>
> ✦ تم تحويل الملصق
> إلى صورة بنجاح.
>
> 🖼️ 𝙵𝙾𝚁𝙼𝙰𝚃 : 𝙹𝙿𝙶
>
> 𝑮𝑬𝑶 × 𝐴𝑅𝐸𝑆`
      },
      { quoted: m }
    )

    await m.react('✔️')

  } catch (e) {
    await m.react('✖️')

    await conn.reply(
      m.chat,
      `> ＃ 𝙽𝙾𝚇 〢 𝙴𝚁𝚁𝙾𝚁
>
> ⚠️ حدث خطأ أثناء التحويل.
> حاول مرة أخرى لاحقاً.
>
> 𝑮𝑬𝑶 × 𝐴𝑅𝐸𝑆`,
      m
    )

    console.error(e)
  }
}

handler.help = ['لصورة']
handler.tags = ['tools']
handler.command = ['لصورة', 'jpg', 'img']

export default handler