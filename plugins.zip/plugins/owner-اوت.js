/*
⌁ 𝐍𝐎𝐗 ⌁
𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆

「 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐛𝐲 𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆 」
「 لا تحذف الحقوق 🖤 」
𝐍𝐎𝐗 channel
https://whatsapp.com/channel/0029VbCeOCi7tkjC9bGs3U0l
𝙎𝙃𝘼𝙉𝙆𝙎 channel
مافيش قناه حاليا فاا 👽♥️
 📜 𝙏𝙝𝙞𝙨 𝙞𝙨 𝙩𝙝𝙚 𝙍𝙀𝙋𝙊 𝙡𝙞𝙣𝙠 𝙬𝙞𝙩𝙝 𝙖𝙡𝙡 𝙩𝙝𝙚 𝙘𝙤𝙙𝙚𝙨:
⚡ https://github.com/SHANKS-CODE-1/CODE
*/

let handler = async (m, { conn, usedPrefix, command }) => {
    const ownerNumber = "5512981547738";

    let senderNumber = m.sender.replace(/[^0-9]/g, '');

    if (senderNumber !== ownerNumber) {
        return m.reply("❌ هذا الأمر مخصص لمطور ويليام فقط!");
    }

    if (!m.isGroup) {
        return m.reply("❌ هذا الأمر يتم تنفيذه داخل المجموعات فقط.");
    }

    try {
        await conn.sendMessage(m.chat, {
            text: "حاضر مطوري جيو 🤍"
        }, { quoted: m });

        await new Promise(resolve => setTimeout(resolve, 1000));

        await conn.groupLeave(m.chat);

    } catch (e) {
        console.error(e);
        m.reply("❌ حدث خطأ أثناء محاولة خروج جيو من المجموعة.");
    }
};

handler.help = ["اوت"];
handler.tags = ["owner"];
handler.command = /^(اوت)$/i;
handler.group = true;

export default handler;