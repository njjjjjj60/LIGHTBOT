/*
⌁ 𝐍𝐎𝐗 ⌁
𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆

「 𝐂𝐫𝐞𝐝𝐢𝐭𝐬 𝐛𝐲 𝑮𝑬𝑶 𝚇 𝐴𝑅𝐸𝑆 」
「 لا تحذف الحقوق 🖤 」
𝐍𝐎𝐗 channel
https://whatsapp.com/channel/0029VbCeOCi7tkjC9bGs3U0l
𝙎𝙃𝘼𝙉𝙆𝙎 channel
مافيش قناه حاليا فاا 👽♥️
 📜 𝙏𝙝𝙞𝙨 𝙞𝙨 𝙩𝙝𝙚 𝙍𝙀𝙋𝙊 𝙡𝙞𝙣𝙠 𝙬𝙞𝙩𝙝 𝙖𝙡𝙡 𝙩𝙝𝙚 𝙘𝙤𝙙𝙚𝙨:
⚡ https://github.com/SHANKS-CODE-1/CODE
*/

let handler = async (m, { conn }) => {
    await m.react('👑')

    let list = [
        {
            displayName: '𝐴𝑅𝐸𝑆',
            vcard: `BEGIN:VCARD
VERSION:3.0
FN:𝐴𝑅𝐸𝑆
TEL;type=CELL;waid=5512981547738:+55 12981547738
END:VCARD`
        },
        {
            displayName: '𝑮𝑬𝑶',
            vcard: `BEGIN:VCARD
VERSION:3.0
FN:𝑮𝑬𝑶
TEL;type=CELL;waid=5512981547738:+55 12981547738
END:VCARD`
        }
    ]

    const canalInfo = {
        title: '⌁ 𝐍𝐎𝐗 𝐁𝐎𝐓 ⌁',
        body: '𝐴𝑅𝐸𝑆 𝚇 𝑮𝑬𝑶',
        thumbnailUrl: 'https://files.catbox.moe/iq1skp.jpg',
        sourceUrl: 'مافيش قناه حاليا فاا 👽♥️',
        mediaType: 1,
        renderLargerThumbnail: true
    }

    await conn.sendMessage(
        m.chat,
        {
            contacts: {
                displayName: `${list.length} Contacts`,
                contacts: list
            },
            contextInfo: {
                externalAdReply: canalInfo
            }
        },
        { quoted: m }
    )

    let txt = `╭━━━〔 ⌁ 𝐍𝐎𝐗 ⌁ 〕━━━╮
┃
┃ 👑 *𝐌𝐘𝐒𝐓𝐄𝐑𝐘 𝐎𝐅 𝐍𝐎𝐗*
┃
┃ ⚔️ 𝑮𝑬𝑶
┃    ↳ +55 1298 1547 738
┃
╰━━━━━━━━━━━━━━━━━━╯

╭━━〔 📡 𝐍𝐎𝐗 𝐂𝐇𝐀𝐍𝐍𝐄𝐋 〕━━╮
┃
┃ 🌑 𝐍𝐎𝐗 𝐓𝐄𝐂𝐇
┃ ↳ مافيش قناه حاليا فاا 👽♥️
┃
╰━━━━━━━━━━━━━━━━━━╯

「 𝐴𝑅𝐸𝑆 𝚇 𝑮𝑬𝑶 」
⌁ 𝐍𝐎𝐗 𝐁𝐎𝐓 ⌁`

    await conn.sendMessage(
        m.chat,
        {
            text: txt,
            ...rcanal
        },
        { quoted: m }
    )
}

handler.help = ['owner', 'المطور']
handler.tags = ['info']
handler.command = ['owner', 'creator', 'creador', 'dueño', 'المطور']

export default handler